@extends('errors.layout')

@section('seo_title', '503 Error')

@section('page_title', '503')

@section('message', 'YOU SEEM TO BE TRYING TO FIND HIS WAY HOME') 
