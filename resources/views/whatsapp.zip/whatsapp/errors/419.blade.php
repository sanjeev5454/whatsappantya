@extends('errors.layout')

@section('seo_title', '419 Error')

@section('page_title', '419')

@section('message', 'YOU SEEM TO BE TRYING TO FIND HIS WAY HOME') 
