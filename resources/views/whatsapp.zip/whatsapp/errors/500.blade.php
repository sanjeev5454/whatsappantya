@extends('errors.layout')

@section('seo_title', '500 Error')

@section('page_title', '500')

@section('message', 'YOU SEEM TO BE TRYING TO FIND HIS WAY HOME') 