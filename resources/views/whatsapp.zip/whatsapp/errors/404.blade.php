@extends('errors.layout')

@section('seo_title', '404 Error')

@section('page_title', '404')

@section('message', 'YOU SEEM TO BE TRYING TO FIND HIS WAY HOME') 
