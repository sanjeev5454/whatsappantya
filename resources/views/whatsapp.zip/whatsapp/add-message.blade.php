@extends('whatsapp.layout.app')
@section('title', 'Add Message')
@section('content')
@include('whatsapp.layout.partials.sidebar') 
<!-- Page -->
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="page creat-fms-box1">
  <div class="page-content container-fluid1">
    <div class="panel">
      <div class="panel-body">
	  <header class="panel-heading">
        <h3 class="panel-title">Add Message</h3>
      </header>
        <div class="row">
          <div class="col-md-6">
            <div class="card">
          <div class="card-body">
            <form method="POST" action="{{ url('whatsapp/savemessage') }}" enctype="multipart/form-data" onsubmit="return itemDataPostValidate();">
               @csrf        
			   <div id="formsteps" class="form-group col-lg-12 col-md-12">
                <div class="form-group row">
                  <div class=" col-lg-12">
                    <label>Receiver Mobile No</label>
                    <input type="text" maxlength="10" class="form-control" autocomplete="off" name="receiver_mobile_no" autocomplete="off" value="{{ old('receiver_mobile_no') }}" id="receiver_mobile_no">
					@if ($errors->has('receiver_mobile_no'))
					<span class="error">{{ $errors->first('receiver_mobile_no') }}</span>
					@endif
				</div>
                </div>
				<div class="form-group row">
                  <div class=" col-lg-12">
                    <label>Message Send Date</label>
                    <input class="form-control" id="datepicker" autocomplete="off" value="{{ old('message_send_date') }}" name="message_send_date" placeholder="YYYY-MM-DD" type="text"/>
					@if ($errors->has('message_send_date'))
					<span class="error">{{ $errors->first('message_send_date') }}</span>
					@endif
					                  </div>
                </div>
				
				<div class="form-group row">
                  <div class=" col-lg-12">
                    <label>Message Text</label>
                    <textarea class="form-control" name="message_text" autocomplete="off" value="" id="address">{{ old('message_text') }}</textarea>
					@if ($errors->has('message_text'))
					<span class="error">{{ $errors->first('message_text') }}</span>
					@endif
                  </div>
                </div>
				
				<div class="form-group row">
				<div class=" col-lg-12">
				<label>File to send</label>
				<div class="input-group mb-3">
				<div class="input-group-prepend">
				<span class="input-group-text" id="basic-addon3">Link with google drive </span>
				</div>
				<input type="text" class="form-control" id="basic-url" aria-describedby="basic-addon3">
				</div>
				</div>
				</div>
				
				
              <div class="form-group row creat-fms-btn">
                <div class="col-md-12">
                  <button type="submit" class="btn btn-success waves-effect waves-classic waves-effect waves-classic waves-effect waves-classic"> Add Message</button>
				  <a href="{{ url('whatsapp') }}" title="Back"><button type="button" class="btn btn-danger waves-effect waves-classic waves-effect waves-classic waves-effect waves-classic"> Back</button></a>
                  </div>
              </div>
			  </div>
            </form>
          </div>
        </div>
          </div>
        </div>
        
      </div>
    </div>
  </div>
</div>
</div>
</div>


@stop 