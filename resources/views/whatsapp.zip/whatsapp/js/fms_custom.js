$(document).ready(function(){
	
	function addfmsDataTable(row_id)
	{
		var cntTh = $('.tbale_header >th').length;
		//$('#tablesearch >tbody').html('');
		var htmlData = '<tr id="row_id_'+row_id+'">';
		for(var i=1; i<cntTh; i++)
		{
			htmlData +='<td><input type="text" name="fmsdata['+row_id+'][]" class="form-control" id="current_row'+row_id+'"></td>';
		}
	
		htmlData +='<td class="actions"><a href="javascript:void(0)" class="btn btn-sm btn-icon btn-success save-row" data-toggle="tooltip" data-original-title="save" id="srow_'+row_id+'"><i class="icon md-check" aria-hidden="true"></i></a> <a href="javascript:void(0)" class="btn btn-sm btn-icon btn-warning save-row" data-toggle="tooltip" data-original-title="Edit"><i class="icon md-edit" aria-hidden="true"></i></a> <a href="javascript:void(0)" id="r_'+row_id+'" class="btn btn-sm btn-icon btn-danger remove-row" data-toggle="tooltip" data-original-title="Remove"><i class="icon md-delete" aria-hidden="true"></i></a></td>';
		
		htmlData +='</tr>';
		$('#tablesearch >tbody').append(htmlData);
		
	}
	addfmsDataTable(1);
	/* to add row in fmsdata */
	$('#addToTable').on('click', function(){
		var cntTr = $('.tbale_header >tbody tr').length;
		var rowNum = cntTr+1;
		
		if(cntTr>0)
		{
			var lastTrid = $('.tbale_header >tbody tr').last().attr('id');
			lastTrid = lastTrid.split('_');
			var lastTridFinal = parseInt(lastTrid[2])+1;
		}else{
			lastTridFinal=1;
		}
		
		addfmsDataTable(lastTridFinal);
		
	});
	
	/* delete selected row */
	$('body').on('click','.remove-row', function(){
		var r_id = $(this).attr('id');
			r_id = r_id.split('_');
			$('#row_id_'+r_id[1]).remove();
		
	});
	
	
	
});